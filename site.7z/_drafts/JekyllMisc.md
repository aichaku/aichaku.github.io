---
layout: post
title: "Jekyll: misc"
comments: true
summary:
tags: [ekyll,blogging]
---

http://matthodan.com/2012/10/27/how-to-create-a-blog-with-jekyll.html Bundler
 emerge jekyll-sitemap
https://github.com/jekyll/jekyll-sitemap  Google sitemap  
