---
layout: post
title: Jekyll is cool
comments: true
summary: Impressed by Jekyll.  It was surprisely easy to switch from txt2site to Jekyll.
gamla_disqus_satte: true
tags: [jekyll,blogging]
---


<div class="message">
My first post in a new Jekyll-based blog!
</div>

I found Jekyll much more powerful than txt2site.

Several useful links if you want to make your Jekyll-based blog:

* [Jekyll docs](http://jekyllrb.com/docs/home/)
* [How I Created a Beautiful and Minimal Blog Using Jekyll, Github Pages, and poole](http://joshualande.com/jekyll-github-pages-poole/)
* [Use txt2tags markup in Jekyll](https://txt2tags.wordpress.com/2014/04/09/use-txt2tags-markup-in-jekyll/)  Extremely useful if you need to move some of your old content from [txt2site](http://home.deds.nl/~svg_experimenten/txt2site/) to Jekyll

Github repo with the sources of this blog can be found here: [https://github.com/vitalyrepin/vrepinblog](https://github.com/vitalyrepin/vrepinblog)


